const config = {
  SOCKET_URL: process.env.EXPO_PUBLIC_SOCKET_URL || "https://prestrack-ai-server.onrender.com",
  APP_NAME: "PreSTrack",
  VERSION: "1.0.0",
}

export default config
